export interface ChartModel {
    data: [],
    label: string
}