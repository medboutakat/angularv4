
export class  Vat{
    displayname:string;
    value:string ; 
    id:string 
}