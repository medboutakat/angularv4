
export class  Bank{
    
    id:string 
    shortName:string;
    name:string ;  
    remark  : string ; 
    // "bankAccounts": null
}