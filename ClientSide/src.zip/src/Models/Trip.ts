 
 
    export class Trip { 
          id: number; 
          name: string; 
          startDate: Date; 
          endDate: Date;
    } 