
export class  ClientCategory{
    id:string;
    name:string;
    remarque:string;
    dateCreate:string;
    dateUpdate:string; 
}
