
export class  Map{
    latitude:string;
    longitude:string; 
} 