
export class  Delivery{
    displayname:string;
    value:string ; 
    id:string 
}