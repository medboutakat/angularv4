
export class employee {
    nom: string = "";
    prenom: string = "";
    email: string = "";
    tele: number = 0;
    photo: string = "";
    dateNaissance: String;
    cin: String;
    lieuNaissance: String;
    sexe: String;
    service: String;
    dateDeb: String;
    adresse: String;
    niveauEtude: String;
    matricule: number = 0;
    ville: string;
    dateFin: String;
    username: string;
    accesMod: string;
    password: string;

}

export class Employee {
    firstname: string;
    lastname: string;
    email: string;
    gender: number;
    id: string
}