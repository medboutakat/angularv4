import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retour',
  templateUrl: './retour.component.html',
  styleUrls: ['./retour.component.sass']
})
export class RetourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
