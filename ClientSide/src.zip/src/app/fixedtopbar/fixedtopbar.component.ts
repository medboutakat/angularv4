import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fixedtopbar',
  templateUrl: './fixedtopbar.component.html',
  styleUrls: ['./fixedtopbar.component.sass']
})
export class FixedtopbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
