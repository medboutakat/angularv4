export class Product { 
    id:string 
    code:string;
    name1:string ;  
    description  : string ; 
    price  : number ; 
    tva  : number ; 
    // "bankAccounts": null
}
