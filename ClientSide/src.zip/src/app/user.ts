export class User {
    id: string;
    firstName: string;
    lastName: string;
    password: string;
    email: string;
    token: string;
}
