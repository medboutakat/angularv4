import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childedit',
  templateUrl: './childedit.component.html',
  styleUrls: ['./childedit.component.css']
})
export class ChildeditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
